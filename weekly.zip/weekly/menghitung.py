import matematika
r = float(input("masukkan jari jari lingkaran: "))
luas_lingkaran = matematika.lingkaran(r)
print('luas lingkaran = ', + luas_lingkaran)
x = float(input("masukkan sisi lingkaran: "))
luas_persegi = matematika.persegi(x)
print('luas persegi = ', + luas_persegi)