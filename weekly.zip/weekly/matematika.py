def lingkaran(r):
    pi = 3.14
    return pi * r**2
def persegi(x):
    return x * x